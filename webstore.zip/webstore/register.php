<?php

include 'config.php';

if(isset($_POST['submit'])){ 

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
    $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
    $user_type = $_POST['user_type'];

    // Checkkaa jos käyttäjä on jo olemassa
    $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('Query failed');

    if(mysqli_num_rows($select_users) > 0){
        $message[] = 'User already exists!';
    } else {
        // Checckaa jos salasanat ovat samoja
        if($pass != $cpass){
            $message[] = 'Passwords do not match!';
        } else {
            // Inserttaa user tietoja databaseen
            mysqli_query($conn, "INSERT INTO `users` (name, email, password, user_type) VALUES ('$name', '$email', '$pass', '$user_type')") or die('Query failed');
            $message[] = 'Registered Successfully';
            header('location:login.php');
        }
    }
}
?>




        
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>register</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

     
<?php if(isset($message)){
    foreach($message as $message){
     //Echo joka kertoo jos kirjautuminen onnistuu
        echo '
        <div class="message">
    <span>'.$message.'</span>
    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
</div>  
        ';
    }
}
    ?>

    <!-- Form register sivuun-->
    
<div class="form-container">  
    <form action="" method="post">
        <h3>  Hello new user!
        </h3>
        <input type="text" name="name" placeholder="enter your name" required class="box">
        <input type="email" name="email" placeholder="enter your email" required class="box">
        <input type="password" name="password" placeholder="enter your password" required class="box">
        <input type="password" name="cpassword" placeholder="confirm your password" required class="box">
        
        <select name="user_type">
            <option value="user">User</option>
            <option value="admin">Admin</option>
        </select>
        <input type="submit" name="submit" value="Create Account" class="btn">
        <p> Already have an account? <a href="login.php">Login here!</p></a>
</div> 

